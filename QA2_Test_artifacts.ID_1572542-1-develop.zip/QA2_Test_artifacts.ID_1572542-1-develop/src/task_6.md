Ресурсы для генерации файлов различного размера:
https://www.fakefilegenerator.com/generate-file.php
https://randvar.com/generator/file



Ресурсы для генерации тестовых данных:
https://www.fakenamegenerator.com/
https://generatedata.com/